#!/bin/bash

sudo python ./setup.py install

